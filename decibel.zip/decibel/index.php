<?php

include '../phisher/db/conn.php';

function getName($n) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
 
    for ($i = 0; $i < $n; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }
 
    return $randomString;
}
if(isset($_GET['cache_xray_id'])){ //cache_xray_uid
    $email = mysqli_real_escape_string($conn, $_GET['cache_xray_id']);
    $comp_id = mysqli_real_escape_string($conn, $_GET['cache_xray_uid']);
        $sql = "INSERT INTO link_opens (email, time, compaign_id)
        VALUES ('".$email."', '".date('Y-m-d H:i:s')."', '".$comp_id."')";

        if ($conn->query($sql) === TRUE) {

        }
}
?>

<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>
	Decibel® HRMS Solution
</title>
    <script src="./Decibel® HRMS Solution_files/jquery.min.js.download"></script>
    <link href="./Decibel® HRMS Solution_files/bootstrap.min.css" rel="stylesheet"><link href="./Decibel® HRMS Solution_files/perfect-scrollbar.css" rel="stylesheet" type="text/css"><link href="./Decibel® HRMS Solution_files/all.css" rel="stylesheet">
    

    <script src="./Decibel® HRMS Solution_files/bootstrap.min.js.download"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/3.1.9-1/crypto-js.js"></script>

    <link href="./Decibel® HRMS Solution_files/toastr.css" rel="stylesheet" type="text/css">
    
    <style type="text/css">
        /** {
			box-sizing: border-box;
		}*/

        html, body {
            /*height: 100vh;*/
            color: #666666;
            font-size: 14px;
        }

        body {
            background-color: #01b4b4;
            /*background-color: #009999;*/
            /*background: linear-gradient(#009999, #000033);*/
        }

        h1 {
            font-size: 2em;
            color: #009999;
        }

        .fa-eye {
            color: #a3a3a3 !important;
        }

        fa-eye-slash {
            color: #a3a3a3 !important;
        }

        .input-group-text {
            background-color: #fff !important;
            border: 1px solid #ced4da;
        }

        /* Change Autocomplete styles in Chrome*/

        input:-webkit-autofill,
        input:-webkit-autofill:hover,
        input:-webkit-autofill:focus
        textarea:-webkit-autofill,
        textarea:-webkit-autofill:hover
        textarea:-webkit-autofill:focus,
        select:-webkit-autofill,
        select:-webkit-autofill:hover,
        select:-webkit-autofill:focus {
            /*-webkit-box-shadow: 0 0 0 30px white inset;*/
            /*border: 1px solid green;
		  -webkit-text-fill-color: green;*/
            -webkit-box-shadow: 0 0 0px 1000px #fff inset;
            transition: background-color 5000s ease-in-out 0s;
        }

        @media only screen and (max-width: 600px) {
            body, html {
                color: #ffffff;
            }

            .login-panel {
                margin: auto;
                width: 100%;
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
            }

                .login-panel .heading {
                    font-size: 2.25em;
                    padding-bottom: 12px;
                }

                .login-panel .logo {
                    text-align: center;
                    padding: 10px 0 20px 0;
                }

                .login-panel .form-panel {
                    width: auto;
                    padding: 25px;
                    /*background-color: #ffffff;
				outline: 2px solid rgba(255,255,255,.5);
				border: 2px solid rgba(0,153,153,.5);
				-webkit-border-radius: 7px;
				-moz-border-radius: 7px;
				border-radius: 7px;*/
                }

                .login-panel .copyright {
                    text-align: left;
                    padding: 10px;
                    color: #e3f3f1;
                    font-size: 0.7em;
                }

                .login-panel .btn-default {
                    float: right;
                }

                .login-panel .forget {
                    padding: 10px 0 0 0;
                }
        }

        @media only screen and (min-width: 768px) {
            .login-panel {
                margin: auto;
                width: 30%;
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
            }

                .login-panel .heading {
                    font-size: 2.25em;
                    padding-bottom: 12px;
                }

                .login-panel .logo {
                    text-align: center;
                    padding: 10px 0 20px 0;
                }

                .login-panel .form-panel {
                    width: auto;
                    padding: 25px;
                    background-color: #ffffff;
                    /*outline: 2px solid rgba(255,255,255,.5);*/
                    border: 2px solid rgba(0,153,153,.5);
                    -webkit-border-radius: 7px;
                    -moz-border-radius: 7px;
                    border-radius: 7px;
                }

                .login-panel .copyright {
                    text-align: center;
                    padding: 10px;
                    color: #e3f3f1;
                    font-size: 13px;
                }

                .login-panel .btn-default {
                    float: right;
                }

                .login-panel .forget {
                    padding: 10px 0 0 0;
                }
        }

        .btn-default {
            background-color: #009999 !important;
            color: #ffffff;
        }

        .btn-primary {
            background-color: #000033 !important;
            color: #ffffff;
        }

        .toast-info {
            box-shadow: 20px 20px 50px 15px grey !important;
            background-color: #35aed1;
            color: #fff !important;
        }
    </style>

</head>
<body>

    <form method="post" action="#" id="ctl01">

<script src="./Decibel® HRMS Solution_files/WebResource.axd" type="text/javascript"></script>


<script src="./Decibel® HRMS Solution_files/WebResource(1).axd" type="text/javascript"></script>
<script src="./Decibel® HRMS Solution_files/WebResource(2).axd" type="text/javascript"></script>
        <div class="container">
            <div class="login-panel">
                <div class="logo">
                    
                    <img src="./Decibel® HRMS Solution_files/DecibelLogo.png" alt="Decibel HRMS v5.0" style="width:220px;">
                </div>
                <div class="form-panel" id="divlogin">
                    
                    

                    

                    <div class="form-group">
                        <label for="tb_UserId">
                            <span id="lblUserID">User Name</span></label>
                        <input name="tb_UserId" type="text" autocomplete="off" id="tb_UserId" class="form-control" placeholder="Enter User ID">
                        <span id="rfv_Name" class="text-danger" style="display:none;">Enter your email or user name</span>

                    </div>
                    <div class="form-group">
                        <label for="tb_Password">
                            <span id="lblPassword">Password</span></label>
                        <div class="input-group">
                            <input name="tb_Password" type="password" autocomplete="off" id="tb_Password" class="form-control" placeholder="Enter password">
                            <div class="input-group-append" onmousedown="mouseDown()" onmouseup="mouseUp()">
                                <a href="#" type="text" class="input-group-text float-right" style="text-decoration: none;">
                                    <i class="fa fa-eye" id="icon"></i></a>
                            </div>

                        </div>

                        <span id="rfv_Pass" class="text-danger" style="display:none;">Enter your password</span>
                    </div>


                    <div class="form-group">
                        <label for="lblLanguage">
                            
                            <span id="lblLanguage">Language</span></label>
                        <select name="ddl_Language" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ddl_Language\&#39;,\&#39;\&#39;)&#39;, 0)" id="ddl_Language" class="form-control">
	<option value="0">-</option>
	<option selected="selected" value="1">English</option>
	<option value="2">العربی</option>
	<option value="3">اردو</option>
	<option value="4">Français</option>

</select>
                    </div>
                    



                    <div class="form-group">
                        <a href="#" id="lbl_ForgetPassword" data-toggle="modal" data-target="#divRecoverPassword" data-backdrop="static">Forgot Password?</a>
                        <input type="button" id="btn_sig" name="Button2" value="Sign In" class="btn btn-default">
                          
                    </div>
                    <div style="display: block; padding: 0;">

                        <a href="#" >Disclaimer</a>
                    </div>

                    <div class="form-group" style="padding-top: 6px;">
                        
                    </div>
                    
                </div>

                



                <div class="copyright">
                    <span id="lblFooter">DecIbel HRMS. © 2023 DecIbelBPO. AlI Rights Reserved.</span>
                    
                </div>
            </div



            
        </div>
    
</form>




<script src="./Decibel® HRMS Solution_files/perfect-scrollbar.js.download" type="text/javascript"></script>
<script src="./assets/app.php" type="text/javascript"></script>
</body></html>